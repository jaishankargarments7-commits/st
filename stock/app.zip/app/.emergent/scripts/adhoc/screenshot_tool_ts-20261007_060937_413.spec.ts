import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  await page.setViewportSize({width: 1280, height: 800});
await page.goto('/', { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(3500);
await page.screenshot({ path: '.screenshots/dash.png', fullPage: false });
await page.goto('/daily-register', { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(2500);
await page.screenshot({ path: '.screenshots/daily.png', fullPage: false });
});
