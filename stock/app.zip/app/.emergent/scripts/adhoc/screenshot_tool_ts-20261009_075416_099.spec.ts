import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  await page.setViewportSize({width: 1280, height: 800});
await page.goto('/invoices', { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(3500);
await page.screenshot({ path: '.screenshots/inv.png', fullPage: false });
await page.click('[data-testid="btn-new-sales"]', { force: true });
await page.waitForTimeout(1200);
await page.screenshot({ path: '.screenshots/inv_modal.png', fullPage: false });
});
