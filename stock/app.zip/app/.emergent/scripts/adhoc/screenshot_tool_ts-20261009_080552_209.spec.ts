import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  await page.setViewportSize({width: 1280, height: 800});
await page.goto('/gst-reports', { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(3500);
await page.screenshot({ path: '.screenshots/gst.png', fullPage: false });
await page.goto('/entry', { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(2500);
await page.screenshot({ path: '.screenshots/entry.png', fullPage: false });
await page.click('[data-testid="card-transfer"]', { force: true });
await page.waitForTimeout(1000);
await page.screenshot({ path: '.screenshots/transfer.png', fullPage: false });
});
